<?php

//fetch.php

include("database_connection.php");

$query = "SELECT * FROM jobs";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$total_row = $statement->rowCount();
$output = '
<table class="table table-striped table-bordered">
	<tr>
		<th>Job Name</th>
		<th>Description</th>
		<th>Requirements</th>
		<th>Email</th>
		<th>Link</th>
		<th>City</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
';
if($total_row > 0)
{
	foreach($result as $row)
	{
		$output .= '
		<tr>
			<td width="40%">'.$row["jobname"].'</td>
			<td width="40%">'.$row["description"].'</td>
			<td width="40%">'.$row["requirements"].'</td>
			<td width="40%">'.$row["email"].'</td>
			<td width="40%">'.$row["link"].'</td>
			<td width="40%">'.$row["location"].'</td>
			<td width="10%">
				<button type="button" name="edit" class="btn btn-primary btn-xs edit" id="'.$row["id"].'">Edit</button>
			</td>
			<td width="10%">
				<button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$row["id"].'">Delete</button>
			</td>
		</tr>
		';
	}
}
else
{
	$output .= '
	<tr>
		<td colspan="4" align="center">Data not found</td>
	</tr>
	';
}
$output .= '</table>';
echo $output;
?>