<html>  
    <head>  
        <title>Job Portal</title>  
		<link rel="stylesheet" href="jquery-ui.css">
        <link rel="stylesheet" href="bootstrap.min.css" />
		<script src="jquery.min.js"></script>  
		<script src="jquery-ui.js"></script>
    </head>  
    <body>  
        <div class="container">
			<br />
			
			<h3 align="center">Job Portal</a></h3><br />
			<br />
			<div align="right" style="margin-bottom:5px;">
			<button type="button" name="add" id="add" class="btn btn-success btn-xs">Add</button>
			</div>
			<div class="table-responsive" id="user_data">
				
			</div>
			<br />
		</div>
		
		<div id="user_dialog" title="Add Data">
			<form method="post" id="user_form">
				<div class="form-group">
					<label>Enter Job Name</label>
					<input type="text" name="Job Name" id="Job Name" class="form-control" />
					<span id="error_Job Name" class="text-danger"></span>
				</div>
				<div class="form-group">
					<label>Enter Description</label>
					<input type="text" name="Description" id="Description" class="form-control" />
					<span id="error_Description" class="text-danger"></span>
				</div>
				<div class="form-group">
					<label>Enter Requirements</label>
					<input type="text" name="Requirements" id="Requirements" class="form-control" />
					<span id="error_Requirements" class="text-danger"></span>
				</div>
				<!-- <div class="form-group">
					<label>Enter City</label>
					<input type="text" name="City" id="City" class="form-control" />
					<span id="error_City" class="text-danger"></span>
				</div> -->
				<!-- <div class="form-group">
					<label>Enter Email</label>
					<input type="text" name="Email" id="Email" class="form-control" />
					<span id="error_Email" class="text-danger"></span>
				</div> -->
				<div class="form-group">
					<label>Enter Link</label>
					<input type="text" name="Link" id="Link" class="form-control" />
					<span id="error_Link" class="text-danger"></span>
				</div>
				<div class="form-group">
					<input type="hidden" name="action" id="action" value="insert" />
					<input type="hidden" name="hidden_id" id="hidden_id" />
					<input type="submit" name="form_action" id="form_action" class="btn btn-info" value="Insert" />
				</div>
			</form>
		</div>
		
		<div id="action_alert" title="Action">
			
		</div>
		
		<div id="delete_confirmation" title="Confirmation">
		<p>Are you sure you want to Delete this data?</p>
		</div>
		
    </body>  
</html>  




<script>  
$(document).ready(function(){  

	load_data();
    
	function load_data()
	{
		$.ajax({
			url:"fetch.php",
			method:"POST",
			success:function(data)
			{
				$('#user_data').html(data);
			}
		});
	}
	
	$("#user_dialog").dialog({
		autoOpen:false,
		width:400
	});
	
	$('#add').click(function(){
		$('#user_dialog').attr('title', 'Add Data');
		$('#action').val('insert');
		$('#form_action').val('Insert');
		$('#user_form')[0].reset();
		$('#form_action').attr('disabled', false);
		$("#user_dialog").dialog('open');
	});
	
	$('#user_form').on('submit', function(event){
		event.preventDefault();
		var error_Job Name = '';
		var error_Description = '';
		var error_Requirements = '';
		var error_City = '';
		var error_Email = '';
		var error_Link = '';
		if($('#Job Name').val() == '')
		{
			error_Job Name = 'Job Name is required';
			$('#error_Job Name').text(error_Job Name);
			$('#Job Name').css('border-color', '#cc0000');
		}
		else
		{
			error_Job Name = '';
			$('#error_Job Name').text(error_Job Name);
			$('#Job Name').css('border-color', '');
		}
		if($('#Description').val() == '')
		{
			error_Description = 'Description is required';
			$('#error_Description').text(error_Description);
			$('#Description').css('border-color', '#cc0000');
		}
		else
		{
			error_Description = '';
			$('#error_Description').text(error_Description);
			$('#Description').css('border-color', '');
		}
		if($('#Requirements').val() == '')
		{
			error_Requirements = 'Requirements is required';
			$('#error_Requirements').text(error_Requirements);
			$('#Requirements').css('border-color', '#cc0000');
		}
		else
		{
			error_Requirements = '';
			$('#error_Requirements').text(error_Requirements);
			$('#Requirements').css('border-color', '');
		}
		if($('#City').val() == '')
		{
			error_City = 'City is required';
			$('#error_City').text(error_City);
			$('#City').css('border-color', '#cc0000');
		}
		else
		{
			error_City = '';
			$('#error_City').text(error_City);
			$('#City').css('border-color', '');
		}
		if($('#Email').val() == '')
		{
			error_Email = 'Email is required';
			$('#error_Email').text(error_Email);
			$('#Email').css('border-color', '#cc0000');
		}
		else
		{
			error_Email = '';
			$('#error_Email').text(error_Email);
			$('#Email').css('border-color', '');
		}
		if($('#Link').val() == '')
		{
			error_Link = 'Link is required';
			$('#error_Link').text(error_Link);
			$('#Link').css('border-color', '#cc0000');
		}
		else
		{
			error_Link = '';
			$('#error_Link').text(error_Link);
			$('#Link').css('border-color', '');
		}
		
		if(error_Job Name != '' || error_Description != '')
		{
			return false;
		}
		else
		{
			$('#form_action').attr('disabled', 'disabled');
			var form_data = $(this).serialize();
			$.ajax({
				url:"action.php",
				method:"POST",
				data:form_data,
				success:function(data)
				{
					$('#user_dialog').dialog('close');
					$('#action_alert').html(data);
					$('#action_alert').dialog('open');
					load_data();
					$('#form_action').attr('disabled', false);
				}
			});
		}
		
	});
	
	$('#action_alert').dialog({
		autoOpen:false
	});
	
	$(document).on('click', '.edit', function(){
		var id = $(this).attr('id');
		var action = 'fetch_single';
		$.ajax({
			url:"action.php",
			method:"POST",
			data:{id:id, action:action},
			dataType:"",
			success:function(data)
			{
				$('#Job Name').val(data.Job Name);
				$('#Description').val(data.Description);
				$('#Requirements').val(data.Requirements);
				$('#City').val(data.City);
				$('#Email').val(data.Email);
				$('#Link').val(data.Link);
                $('#user_dialog').attr('title', 'Edit Data');
				$('#action').val('update');
				$('#hidden_id').val(id);
				$('#form_action').val('Update');
				$('#user_dialog').dialog('open');
			}
		});
	});
	
	$('#delete_confirmation').dialog({
		autoOpen:false,
		modal: true,
		buttons:{
			Ok : function(){
				var id = $(this).data('id');
				var action = 'delete';
				$.ajax({
					url:"action.php",
					method:"POST",
					data:{id:id, action:action},
					success:function(data)
					{
						$('#delete_confirmation').dialog('close');
						$('#action_alert').html(data);
						$('#action_alert').dialog('open');
						load_data();
					}
				});
			},
			Cancel : function(){
				$(this).dialog('close');
			}
		}	
	});
	
	$(document).on('click', '.delete', function(){
		var id = $(this).attr("id");
		$('#delete_confirmation').data('id', id).dialog('open');
	});
	
});  
</script>