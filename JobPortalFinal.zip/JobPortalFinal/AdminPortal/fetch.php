<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "userdata");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM jobs 
  WHERE location LIKE '%".$search."%' 

 ";
//add following data if need to search via new field (query)
  // OR Address LIKE '%".$search."%' 
  // OR City LIKE '%".$search."%' 
  // OR PostalCode LIKE '%".$search."%' 
  // OR Country LIKE '%".$search."%'


}
else
{
 $query = "
  SELECT * FROM jobs ORDER BY id DESC
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     <th>Job Name</th>
     <th>Description</th>
     <th>Requirements</th>
     <th>Email</th>
     <th>Link</th>
     <th>Location</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
    <td>'.$row["jobname"].'</td>
    <td>'.$row["description"].'</td>
    <td>'.$row["requirements"].'</td>
    <td>'.$row["email"].'</td>
    <td><a href="https://'.$row["link"].'">Apply from here</td>
    <td>'.$row["location"].'</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'No Data Available!';
}

?>