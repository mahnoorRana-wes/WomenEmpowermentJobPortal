<?php

//action.php

include('database_connection.php');

if(isset($_POST["action"]))
{
	if($_POST["action"] == "insert")
	{
		$query = "
		INSERT INTO jobs (jobname,requirements, description,  link, email,location ) VALUES ('".$_POST["jobname"]."','".$_POST["requirements"]."' , '".$_POST["description"]."',  '".$_POST["link"]."', '".$_POST["email"]."',  '".$_POST["location"]."')
		";
		$statement = $connect->prepare($query);
		$statement->execute() ;

		echo '<p>Data Inserted...</p>';
	}
	if($_POST["action"] == "fetch_single")
	{
		$query = "
		SELECT * FROM jobs WHERE id = '".$_POST["id"]."'
		";
		$statement = $connect->prepare($query);
		$statement->execute();
		$result = $statement->fetchAll();
		foreach($result as $row)
		{
			$output['jobname'] = $row['jobname'];
			$output['description'] = $row['description'];
			$output['link'] = $row['link'];
			$output['email'] = $row['email'];
			$output['location'] = $row['location'];
			$output['requirements'] = $row['requirements'];



		}
		echo json_encode($output);
	}
	if($_POST["action"] == "update")
	{
		$query = "
		UPDATE jobs 
		SET jobname = '".$_POST["jobname"]."', 
		description = '".$_POST["description"]."' ,
		link = '".$_POST["link"]."' ,
		email = '".$_POST["email"]."', 
		requirements = '".$_POST["requirements"]."',
		location = '".$_POST["location"]."' 
		WHERE id = '".$_POST["hidden_id"]."'
		";
		$statement = $connect->prepare($query);
		$statement->execute();
		echo '<p>Data Updated</p>';
	}
	if($_POST["action"] == "delete")
	{
		$query = "DELETE FROM jobs WHERE id = '".$_POST["id"]."'";
		$statement = $connect->prepare($query);
		$statement->execute();
		echo '<p>Data Deleted</p>';
	}
}

?>